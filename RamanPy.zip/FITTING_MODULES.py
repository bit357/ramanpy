import numpy as np
import pandas as pd
import matplotlib.pyplot as plt                                       
from scipy.optimize import curve_fit
import warnings
from scipy.optimize import differential_evolution
from tkinter import *
from tkinter import ttk
from tkinter import messagebox



def Raman(file,c) :
    if c==1.1:
            data = pd.read_csv(file)
            data.columns=['w','i']
            df1, df2 = [x for _, x in data.groupby(data['w'] < 1500)]
            df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1700)]
            dfg=df4

            dfg.to_csv('gpeak.csv', index=False,header=False)

            def Lorentz(x, a, b, A, w, x_0):
                return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))



            def sumOfSquaredError(parameterTuple):
                warnings.filterwarnings("ignore")
                return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


            def generate_Initial_Parameters():

                maxX = max(xData)
                minX = min(xData)
                maxY = max(yData)
                minY = min(yData)
    
                parameterBounds = []
                parameterBounds.append([-1.0, 1.0])
                parameterBounds.append([maxY/-2.0, maxY/2.0])
                parameterBounds.append([0.0, maxY*100.0])
                parameterBounds.append([0.0, maxY/2.0])
                parameterBounds.append([minX, maxX]) 
    

                result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
                return result.x


            xData,yData = np.loadtxt('gpeak.csv',delimiter=',',unpack= True)



            initialParameters = generate_Initial_Parameters()


            fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


            a, b, A, w, x_0 = fittedParameters
            y_fit = Lorentz(xData, a, b, A, w, x_0)
            ig=A
    
    
            data = pd.read_csv(file)
            data.columns=['w','i']
            df1, df2 = [x for _, x in data.groupby(data['w'] < 2500)]
            df3, df8 = [x for _, x in df1.groupby(df1['w'] < 2900)]
            df2d=df8

            df2d.to_csv('2dpeak.csv', index=False,header=False)

            def Lorentz1(x, a2d, b2d, A2d, w2d, x_02d):
                return a2d*x+b2d+(2*A2d/np.pi)*(w2d/(4*(x-x_02d)**2 + w2d**2))




            def sumOfSquaredError1(parameterTuple):
                warnings.filterwarnings("ignore")
                return np.sum((yData - Lorentz1(xData, *parameterTuple)) ** 2)



            def generate_Initial_Parameters1():
                maxX = max(xData)
                minX = min(xData)
                maxY = max(yData)
                minY = min(yData)
    
                parameterBounds = []
                parameterBounds.append([-1.0, 1.0])
                parameterBounds.append([maxY/-2.0, maxY/2.0])
                parameterBounds.append([0.0, maxY*100.0]) 
                parameterBounds.append([0.0, maxY/2.0]) 
                parameterBounds.append([minX, maxX]) 
    

                result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
                return result.x


            xData,yData = np.loadtxt('2dpeak.csv',delimiter=',',unpack= True)



            initialParameters1 = generate_Initial_Parameters1()


            fittedParameters1, pcov = curve_fit(Lorentz1, xData, yData, initialParameters1)


            a2d, b2d, A2d, w2d, x_02d = fittedParameters1
            y_2dfit = Lorentz1(xData, a2d, b2d, A2d, w2d, x_02d)
    
            ig=fittedParameters[2]
            i2d=fittedParameters1[2]
            ratio=ig/i2d
            if ratio>=2:
                si=1
            else:
                si=0
            fwhm=fittedParameters1[3]
            if fwhm==35:
                sf=1
            else:
                sf=0
            posg=fittedParameters[4]
            if posg==1580:
                spg=1
            else:
                spg=0
            pos2d=fittedParameters1[4]
            if pos2d==2700:
                sp2d=1
            else:
                sp2d=0
            tot =si+sf+spg+sp2d
        
            if tot == 4:
                saveLine='PRISTINE MONOLAYER'
                savefile=open('MONOLAYER_GRAPHENE_OUT.txt','w+')
                savefile.write(saveLine)
                savefile.close()
            elif tot==3:
                saveLine='Possible MONOLAYER with Physical effects influencing the Raman Spectra'
                savefile=open('MONOLAYER_GRAPHENE_out.txt','w+')
                savefile.write(saveLine)
                savefile.close()
            else:
                saveLine='NOT A MONOLAYER'
                savefile=open('MONOLAYER_GRAPHENE_output.txt','w+')
                savefile.write(saveLine)
                savefile.close()
                
#############################################################################                
    elif c==1.5:
         data = pd.read_csv(file)
         data.columns=['w','i']
         df1, df2 = [x for _, x in data.groupby(data['w'] < 1500)]
         df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1700)]
         dfg=df4
         dfg.to_csv('gpeak.csv', index=False,header=False)

         def Lorentz(x, a, b, A, w, x_0):
             return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




         def sumOfSquaredError(parameterTuple):
             warnings.filterwarnings("ignore") 
             return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


         def generate_Initial_Parameters():
   
             maxX = max(xData)
             minX = min(xData)
             maxY = max(yData)
             minY = min(yData)
    
             parameterBounds = []
             parameterBounds.append([-1.0, 1.0]) 
             parameterBounds.append([maxY/-2.0, maxY/2.0]) 
             parameterBounds.append([0.0, maxY*100.0])
             parameterBounds.append([0.0, maxY/2.0])
             parameterBounds.append([minX, maxX]) 
    

             result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
             return result.x


         xData,yData = np.loadtxt('gpeak.csv',delimiter=',',unpack= True)


         initialParameters = generate_Initial_Parameters()

         fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


         a, b, A, w, x_0 = fittedParameters
         y_fit = Lorentz(xData, a, b, A, w, x_0)
    
    
         data = pd.read_csv(file)
         data.columns=['w','i']
         df1, df2 = [x for _, x in data.groupby(data['w'] < 2500)]
         df3, df8 = [x for _, x in df1.groupby(df1['w'] < 2900)]
         df2d=df8

         df2d.to_csv('2dpeak.csv', index=False,header=False)
 
         def Lorentz1(x, a2d, b2d, A2d, w2d, x_02d):
             return a2d*x+b2d+(2*A2d/np.pi)*(w2d/(4*(x-x_02d)**2 + w2d**2))




         def sumOfSquaredError1(parameterTuple):
             warnings.filterwarnings("ignore")
             return np.sum((yData - Lorentz1(xData, *parameterTuple)) ** 2)
 
 
         def generate_Initial_Parameters1():
 
             maxX = max(xData)
             minX = min(xData)
             maxY = max(yData)
             minY = min(yData)
     
             parameterBounds = []
             parameterBounds.append([-1.0, 1.0])
             parameterBounds.append([maxY/-2.0, maxY/2.0])
             parameterBounds.append([0.0, maxY*100.0]) 
             parameterBounds.append([0.0, maxY/2.0]) 
             parameterBounds.append([minX, maxX]) 
     
 
             result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
             return result.x
 
 
         xData,yData = np.loadtxt('2dpeak.csv',delimiter=',',unpack= True)
 
 
 
         initialParameters1 = generate_Initial_Parameters1()
 
 
         fittedParameters1, pcov = curve_fit(Lorentz1, xData, yData, initialParameters1)
 
 
         a2d, b2d, A2d, w2d, x_02d = fittedParameters1
         y_2dfit = Lorentz1(xData, a2d, b2d, A2d, w2d, x_02d)
     
         ig=fittedParameters[2]
         i2d=fittedParameters1[2]
         ratio=ig/i2d
         saveLine='IG/I2D ratio ='+' '+ str(ratio)
         savefile=open('IG_I2D_ratio.txt','w+')
         savefile.write(saveLine)
         savefile.close()
    ######################################################################################################
    
    elif c == 1.2:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 1500)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1700)]
        df2d=df4

        df2d.to_csv('gpeak.csv', index=False,header=False)


        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))



        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():
    # min and max used for bounds
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
    

            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('gpeak.csv',delimiter=',',unpack= True)


        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo')
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for G peak = ' + str(x_0) 
        savefile=open('G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    
###########################################################################################################
    elif c ==1.3:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 2500)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 2900)]
        df2d=df4

        df2d.to_csv('2dpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0])
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
    

            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('2dpeak.csv',delimiter=',',unpack= True)



        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo')
        plt.plot(xData, y_fit,'r--')
        plt.savefig("2D_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for 2D peak = ' + str(x_0) 
        savefile=open('2D_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    
    ######################################################################################################################
    
    elif c == 1.4:
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 1300)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1400)]
        df2d=df4

        df2d.to_csv('dpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))

        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():
   
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0])
            parameterBounds.append([0.0, maxY/2.0])
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x

        xData,yData = np.loadtxt('dpeak.csv',delimiter=',',unpack= True)



        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo') # plot the raw data
        plt.plot(xData, y_fit,'r--') # plot the equation using the fitted parameters
        plt.savefig("D_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for D peak = ' + str(x_0) 
        savefile=open('D_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    ###################################################################################################################################
    
    elif c == 1.6:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 1500)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1700)]
        dfg=df4

        dfg.to_csv('gpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('gpeak.csv',delimiter=',',unpack= True)


        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
    
    
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 1300)]
        df3, df8 = [x for _, x in df1.groupby(df1['w'] < 1400)]
        df2d=df8

        df2d.to_csv('dpeak.csv', index=False,header=False)

        def Lorentz1(x, a2d, b2d, A2d, w2d, x_02d):
            return a2d*x+b2d+(2*A2d/np.pi)*(w2d/(4*(x-x_02d)**2 + w2d**2))




        def sumOfSquaredError1(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz1(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters1():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0])
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('dpeak.csv',delimiter=',',unpack= True)


    
        initialParameters1 = generate_Initial_Parameters1()


        fittedParameters1, pcov = curve_fit(Lorentz1, xData, yData, initialParameters1)


        a2d, b2d, A2d, w2d, x_02d = fittedParameters1
        y_2dfit = Lorentz1(xData, a2d, b2d, A2d, w2d, x_02d)
    
        ig=fittedParameters[2]
        i2d=fittedParameters1[2]
        ratio=ig/i2d
        saveLine='IG/ID ratio ='+' '+ str(ratio)
        savefile=open('IG_ID_ratio.txt','w+')
        savefile.write(saveLine)
        savefile.close()
 #########################################################################################################################################################################
 ###############################################################TMDS##################################################
    
    elif c == 2.1:

         data = pd.read_csv(file)
         data.columns=['w','i']
         df1, df2 = [x for _, x in data.groupby(data['w'] < 380)]
         df3, df4 = [x for _, x in df1.groupby(df1['w'] < 450)]
         df2d=df4

         df2d.to_csv('MOS2A1gpeak.csv', index=False,header=False)

         def Lorentz(x, a, b, A, w, x_0):
             return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




         def sumOfSquaredError(parameterTuple):
             warnings.filterwarnings("ignore") 
             return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


         def generate_Initial_Parameters():

             maxX = max(xData)
             minX = min(xData)
             maxY = max(yData)
             minY = min(yData)
             parameterBounds = []
             parameterBounds.append([-1.0, 1.0]) 
             parameterBounds.append([maxY/-2.0, maxY/2.0])
             parameterBounds.append([0.0, maxY*100.0]) 
             parameterBounds.append([0.0, maxY/2.0]) 
             parameterBounds.append([minX, maxX])  
             result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
             return result.x


         xData,yData = np.loadtxt('MOS2A1gpeak.csv',delimiter=',',unpack= True)
         initialParameters = generate_Initial_Parameters()
         fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
         a, b, A, w, x_0 = fittedParameters
         y_fit = Lorentz(xData, a, b, A, w, x_0)
         plt.plot(xData, yData,'bo') 
         plt.plot(xData, y_fit,'r--') 
         plt.savefig("MOS2_A1G_PEAK_FIT.png")
         saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
         savefile=open('MOS2_A1G_PEAK_PARAMETERS.txt','w+')
         savefile.write(saveLine)
         savefile.close()
      ##############################################################################################################################
    elif c == 2.2:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 370)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 400)]
        df2d=df4

        df2d.to_csv('MOS2E12gpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('MOS2E12gpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("MOS2_E12G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('MOS2_E12G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
################################################################################################################################################
            
    elif c == 2.3:
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] <240 )]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 330)]
        dfg=df4

        dfg.to_csv('epeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():
           maxX = max(xData)
           minX = min(xData)
           maxY = max(yData)
           minY = min(yData)
           parameterBounds = []
           parameterBounds.append([-1.0, 1.0]) 
           parameterBounds.append([maxY/-2.0, maxY/2.0])
           parameterBounds.append([0.0, maxY*100.0]) 
           parameterBounds.append([0.0, maxY/2.0]) 
           parameterBounds.append([minX, maxX]) 
           result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
           return result.x


        xData,yData = np.loadtxt('epeak.csv',delimiter=',',unpack= True)


        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
        
    
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 200)]
        df3, df8 = [x for _, x in df1.groupby(df1['w'] < 290)]
        df2d=df8
        df2d.to_csv('apeak.csv', index=False,header=False)

        def Lorentz1(x, a2d, b2d, A2d, w2d, x_02d):
            return a2d*x+b2d+(2*A2d/np.pi)*(w2d/(4*(x-x_02d)**2 + w2d**2))

        def sumOfSquaredError1(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz1(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters1():
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0])
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x
        xData,yData = np.loadtxt('apeak.csv',delimiter=',',unpack= True)
        initialParameters1 = generate_Initial_Parameters1()
        fittedParameters1, pcov = curve_fit(Lorentz1, xData, yData, initialParameters1)
        a2d, b2d, A2d, w2d, x_02d = fittedParameters1
        y_2dfit = Lorentz1(xData, a2d, b2d, A2d, w2d, x_02d)
        ie=fittedParameters[2]
        ia=fittedParameters1[2]
        ratio=ie/ia
        saveLine='IE2_1g/IA_1g ratio ='+' '+ str(ratio)
        savefile=open('MOSE2_IE2_1g/IA_1g_ratio.txt','w+')
        savefile.write(saveLine)
        savefile.close()
        ########################################################################################################################
    
    elif c == 2.4:
        
      
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 200)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 290)]
        df2d=df4
        df2d.to_csv('MOSe2A1gpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))

        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('MOSe2A1gpeak.csv',delimiter=',',unpack= True)



        initialParameters = generate_Initial_Parameters()


        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("MOSe2_A1G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('MOSe2_A1G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
        
    #####################################################################################################################################
    elif c == 2.5:
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 370)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 400)]
        df2d=df4

        df2d.to_csv('MOS2E12gpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))




        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():
    # min and max used for bounds
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
    

            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x


        xData,yData = np.loadtxt('MOS2E12gpeak.csv',delimiter=',',unpack= True)



        initialParameters = generate_Initial_Parameters()

    
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("MOS2_E12G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('MOS2_E12G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
        
       ################################################################################################################################
    
    elif c == 2.6:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 380)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 450)]
        df2d=df4

        df2d.to_csv('ws2A1gpeak.csv', index=False,header=False)

        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))

        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0])
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0])
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x

        xData,yData = np.loadtxt('ws2A1gpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)

        plt.plot(xData, yData,'bo')
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("WS2_A1G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('WS2_A1G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    
    
    
    ##########################################################################################################################################
    elif c == 2.7:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 350)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 400)]
        df2d=df4
        df2d.to_csv('ws2E12gpeak.csv', index=False,header=False)
        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))
        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)
        def generate_Initial_Parameters():
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x

        xData,yData = np.loadtxt('ws2E12gpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)


        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--')
        plt.savefig("WS2_E12G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('WS2_E12G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
        
    
        ##########################################################################################################################################
    elif c == 2.8:
                
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 250)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 270)]
        df2d=df4
        df2d.to_csv('WSE2E12gpeak.csv', index=False,header=False)
        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))
        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)

        def generate_Initial_Parameters():
            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0])
            parameterBounds.append([maxY/-2.0, maxY/2.0])
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0])
            parameterBounds.append([minX, maxX])
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x
    
        xData,yData = np.loadtxt('WSE2E12gpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("WSE2_E12G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('WSE2_E12G_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    
    
    
        ##########################################################################################################################################
    elif c == 2.9:
        
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 200)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 250)]
        df2d=df4
        df2d.to_csv('WSE2A1gpeak.csv', index=False,header=False)
        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))
        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore")
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)
        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0])
            parameterBounds.append([minX, maxX]) 
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x
        xData,yData = np.loadtxt('WSE2A1gpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--') 
        plt.savefig("WSE2_A1G_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for A1G peak = ' + str(x_0) 
        savefile=open('WSE2_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()
    
    
    
    
        ##########################################################################################################################################
    elif c == 3.0:
        
        data = pd.read_csv(file)
        data.columns=['w','i']
        df1, df2 = [x for _, x in data.groupby(data['w'] < 1300)]
        df3, df4 = [x for _, x in df1.groupby(df1['w'] < 1400)]
        df2d=df4
        df2d.to_csv('hbnpeak.csv', index=False,header=False)
        
        def Lorentz(x, a, b, A, w, x_0):
            return a*x+b+(2*A/np.pi)*(w/(4*(x-x_0)**2 + w**2))

        def sumOfSquaredError(parameterTuple):
            warnings.filterwarnings("ignore") 
            return np.sum((yData - Lorentz(xData, *parameterTuple)) ** 2)


        def generate_Initial_Parameters():

            maxX = max(xData)
            minX = min(xData)
            maxY = max(yData)
            minY = min(yData)
    
            parameterBounds = []
            parameterBounds.append([-1.0, 1.0]) 
            parameterBounds.append([maxY/-2.0, maxY/2.0]) 
            parameterBounds.append([0.0, maxY*100.0]) 
            parameterBounds.append([0.0, maxY/2.0]) 
            parameterBounds.append([minX, maxX])
    
  
            result = differential_evolution(sumOfSquaredError, parameterBounds, seed=3)
            return result.x

        xData,yData = np.loadtxt('hbnpeak.csv',delimiter=',',unpack= True)
        initialParameters = generate_Initial_Parameters()
        fittedParameters, pcov = curve_fit(Lorentz, xData, yData, initialParameters)
        a, b, A, w, x_0 = fittedParameters
        y_fit = Lorentz(xData, a, b, A, w, x_0)
        plt.plot(xData, yData,'bo') 
        plt.plot(xData, y_fit,'r--')
        plt.savefig("hBN_PEAK_FIT.png")
        saveLine='FWHM = '+ str(w)+' '+ ' '+' ' +'INTENSITY = ' + str(A) + ' ' +' Wavenumber for hBN peak = ' + str(x_0) 
        savefile=open('hBN_PEAK_PARAMETERS.txt','w+')
        savefile.write(saveLine)
        savefile.close()


    ##########################################################################################################################################        
        
    else:
        print("invalid input")
    return ()


