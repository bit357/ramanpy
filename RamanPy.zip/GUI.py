from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import numpy as np

class App1(ttk.Frame):
    def createWidgets(self):
        #text variables
        self.i_e2g = StringVar()
        self.i_a1g = StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter E2g peak position").grid(row=0, column=0, sticky=W)
        self.label2 = ttk.Label(self, text="Enter A1g peak position:").grid(row=1, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Number of Layer").grid(row=2, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_e2g).grid(row=0, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_a1g).grid(row=1, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.o_nl).grid(row=2, column=1, sticky=E)

        #buttons

        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=3, column=2, sticky=E)

    def calculate(self):
        try:
            self.e2g = float(self.i_e2g.get())
            self.a1g = float(self.i_a1g.get())
            self.d1=self.a1g-self.e2g
            self.nl=8.4/abs((25.8-(abs(self.d1))))
            self.o_nl.set(self.nl)#output variable
        except ValueError:
            messagebox.showinfo("Error", "Invalid Input.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()
        
class App2(ttk.Frame):
    def createWidgets(self):
        #text variables
        self.i_e2g = StringVar()
        self.i_a1g = StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter E2g peak position").grid(row=0, column=0, sticky=W)
        self.label2 = ttk.Label(self, text="Enter A1g peak position:").grid(row=1, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Number of Layer").grid(row=2, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_e2g).grid(row=0, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_a1g).grid(row=1, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.o_nl).grid(row=2, column=1, sticky=E)

        #buttons
       
        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=3, column=2, sticky=E)

    def calculate(self):
        try:
            self.e2g = float(self.i_e2g.get())
            self.a1g = float(self.i_a1g.get())
            self.d2=self.a1g-self.e2g
            self.nl=(np.exp((np.log(np.abs(self.d2))-np.log(57.2))/0.07))-1
            
            self.o_nl.set(self.nl)
        except ValueError:
            messagebox.showinfo("Error", "You can only use numbers.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()

class App3(ttk.Frame):
    def createWidgets(self):

        self.i_g = StringVar()
        self.i_fwhm =StringVar()
        self.i_ratio=StringVar()
        self.i_dpeak=StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter G peak position").grid(row=0, column=0, sticky=W)
        self.label2 = ttk.Label(self, text="Enter FWHM of 2D peak").grid(row=1, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Intensity ratio").grid(row=2, column=0, sticky=W)
        self.label4 = ttk.Label(self, text="Enter position of D peak").grid(row=3, column=0, sticky=W)
        self.label5= ttk.Label(self, text="Characterisation result").grid(row=4, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_g).grid(row=0, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_fwhm).grid(row=1, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.i_ratio).grid(row=2, column=1, sticky=E)
        self.textbox4 = ttk.Entry(self, textvariable=self.i_dpeak).grid(row=3, column=1, sticky=E)
        self.textbox5 = ttk.Entry(self, textvariable=self.o_nl).grid(row=4, column=1, sticky=E)

        #buttons
       
        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=4, column=2, sticky=E)

    def calculate(self):
        try:
            self.g = float(self.i_g.get())
            self.fwhm=float(self.i_fwhm.get())
            self.ratio=float(self.i_ratio.get())
            self.dpeak=float(self.i_dpeak.get())
            if self.fwhm<=35:
                self.s1=1
            else:
                self.s1=0

      
            self.n=(self.g)
            if 1575<=self.n<=1585:
                self.s2=1
            else:
                self.s2=0
            
            self.ic=self.ratio
            if self.ratio>=2:
                self.s3=1
            else:
                self.s3=0
            
            
            self.tc =self.s1+self.s2+self.s3
            
            if self.tc<= 1:
                self.nl="not a monolayer "
            elif self.tc>=2:
                self.nl="Possible monolayer with "
            else:
                self.nl="Please check params"
                
            if 1330<=self.dpeak<=1400:
                self.dp="defects present"
            else:
                self.dp="defects absent"
                
                
            self.o_nl.set(self.nl+ self.dp)
            
        except ValueError:
            messagebox.showinfo("Error", "You can only use numbers.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()
        
        
class App4(ttk.Frame):
    def createWidgets(self):
        #text variables
        self.i_e2g = StringVar()
        self.i_a1g = StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter signature peak position").grid(row=0, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Number of Layer").grid(row=2, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_e2g).grid(row=0, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.o_nl).grid(row=2, column=1, sticky=E)

        #buttons

        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=3, column=2, sticky=E)

    def calculate(self):
        try:
            self.e2g = float(self.i_e2g.get())
            if 1345<=self.e2g<=1365:
                self.nl=1
            elif 1365<=self.e2g<=1385:
                self.nl=" Possible monolayer with Physical effects"
            else:
                self.nl="Not a monolayer"
            
            self.o_nl.set(self.nl)#output variable
        except ValueError:
            messagebox.showinfo("Error", "Invalid Input.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()   
        
        
class App5(ttk.Frame):
    def createWidgets(self):
        #text variables
        self.i_e2g = StringVar()
        self.i_a1g = StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter E2g peak position").grid(row=0, column=0, sticky=W)
        self.label2 = ttk.Label(self, text="Enter A1g peak position:").grid(row=1, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Number of Layer").grid(row=2, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_e2g).grid(row=0, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_a1g).grid(row=1, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.o_nl).grid(row=2, column=1, sticky=E)

        #buttons

        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=3, column=2, sticky=E)

    def calculate(self):
        try:
            self.e2g = float(self.i_e2g.get())
            self.a1g = float(self.i_a1g.get())
            self.d1=self.a1g-self.e2g
            if self.d1==0:
                self.nl=1
            else:
                self.nl="Not a monolayer"
            self.o_nl.set(self.nl)#output variable
        except ValueError:
            messagebox.showinfo("Error", "Invalid Input.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()    
        
                
class App6(ttk.Frame):
    def createWidgets(self):
        #text variables
        self.i_e2g = StringVar()
        self.i_a1g = StringVar()
        self.i_ratio=StringVar()
        self.o_nl = StringVar()

        #labels
        self.label1 = ttk.Label(self, text="Enter E2g peak position").grid(row=0, column=0, sticky=W)
        self.label2 = ttk.Label(self, text="Enter A1g peak position:").grid(row=1, column=0, sticky=W)
        self.label3 = ttk.Label(self, text="Enter E2g/A2g Intensity Ratio:").grid(row=2, column=0, sticky=W)
        self.label4 = ttk.Label(self, text="Number of Layer").grid(row=3, column=0, sticky=W)

        #text boxes
        self.textbox1 = ttk.Entry(self, textvariable=self.i_e2g).grid(row=0, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_a1g).grid(row=1, column=1, sticky=E)
        self.textbox2 = ttk.Entry(self, textvariable=self.i_ratio).grid(row=2, column=1, sticky=E)
        self.textbox3 = ttk.Entry(self, textvariable=self.o_nl).grid(row=3, column=1, sticky=E)

        #buttons

        self.button1 = ttk.Button(self, text="Ok", command=self.calculate).grid(row=3, column=2, sticky=E)

    def calculate(self):
        try:
            self.e2g = float(self.i_e2g.get())
            self.a1g = float(self.i_a1g.get())
            self.d1=abs(self.e2g-self.a1g)
            self.ratio=float(self.i_ratio.get())
            if 20<self.ratio<=25:
                self.c1=1
            else:
                self.c1=0
            if 45<=self.d1<=47:
                self.c2=1
            else:
                 self.c2=0
            self.tc=self.c1+self.c2
            if self.tc==2:
                self.nl="Monolayer"
            elif self.tc==1:
                self.nl="Possible monolayer"
            else:
                self.nl="invalid inputs"
                
            
            
            self.o_nl.set(self.nl)#output variable
        except ValueError:
            messagebox.showinfo("Error", "Invalid Input.")


    def __init__(self, master=None):
        ttk.Frame.__init__(self, master)
        self.grid()
        self.createWidgets()         
        

     
        
def button1_click():
    root = Tk()
    app = App1(master=root)
    app.mainloop()

def button2_click():
    root = Tk()
    app = App2(master=root)
    app.mainloop()
    
def button3_click():
    root = Tk()
    app = App3(master=root)
    app.mainloop()    

def button4_click():
    root = Tk()
    app = App4(master=root)
    app.mainloop()
    
def button5_click():
    root = Tk()
    app = App5(master=root)
    app.mainloop()
    
def button6_click():
    root = Tk()
    app = App6(master=root)
    app.mainloop()    
    
    

def main():

    window = Tk()


    notebook = ttk.Notebook(window)
    frame1 = ttk.Frame(notebook)
    frame2 = ttk.Frame(notebook)
    frame3 = ttk.Frame(notebook)
    frame4 = ttk.Frame(notebook)
    frame5 = ttk.Frame(notebook)
    frame6 = ttk.Frame(notebook)
    notebook.add(frame1, text="for MoS2")
    notebook.add(frame2, text="for WS2")
    notebook.add(frame3, text="for Graphene")
    notebook.add(frame4, text="for h-BN")
    notebook.add(frame5, text="for WSe2")
    notebook.add(frame6, text="for MoSe2")
    notebook.grid()

#Create tab frames
    app1 = App1(master=frame1)
    app1.grid()
    app2 = App2(master=frame2)
    app2.grid()
    app3 = App3(master=frame3)
    app3.grid()
    app4 = App4(master=frame4)
    app4.grid()
    app5 = App5(master=frame5)
    app5.grid()
    app6 = App6(master=frame6)
    app6.grid()
    
    
#Main loop
    window.mainloop()

if __name__ == '__main__':
    main()
